
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class julius {

	private int e_ncrypt;
	
	public julius(String fileName, int encrypt)
	{
		this.e_ncrypt = encrypt;
		String text;
				
		text = readFile(fileName);
	
		if(text == null)
		{
			System.out.println("Empty File");
			
		}
		else
		{
			text = strip(text);
		
			for(int i=0;i<text.length();i++)
			{
				System.out.print(encrypt(text.charAt(i)));
			}
		}
	
	}
	
	private String readFile(String f_name){
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(f_name));
			StringBuffer sBuffer = new StringBuffer();
			String input;
            while((input=reader.readLine()) != null){
            	sBuffer.append(input);
				sBuffer.append("\n");
            }
            reader.close();
            
            return sBuffer.toString();
		} catch (FileNotFoundException e) {
			System.out.println("File was no found");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	private char encrypt(char alpha)
	{

		if(alpha == '\n')
			return alpha;
		
		int charNum = convert.alpha2num(alpha);

		if((charNum + this.e_ncrypt) < 0)
		{
			charNum = charNum + 26 + this.e_ncrypt;
		}
		else
			charNum = (charNum + this.e_ncrypt) % 26;
		
		char charAlpha = convert.num2alpha(charNum);

		
		return charAlpha;
	}
	
	private String strip (String line)
	{
		line = line.replaceAll("[^a-zA-Z^\\n]", "");

		line = line.toLowerCase();
		
		System.out.println(line);
		return line;
	}


	
}
